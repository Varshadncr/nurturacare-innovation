<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Doctor's Information</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
h1 {
    font-size: 50px;
    text-align: center;
    padding-top: 30px;
    color: #000066;
}

img {
    float: left;
    width: 77px;
}

li {
    font-size: 24px;
}

h3 {
    font-size: 24px;
}

p {
    text-align: center;
    font-size: 26px;
}

body {
    margin: 0;
    padding: 0;
    font: 400 15px/1.8 Lato, sans-serif;
    
    width: 100%;
    height: 100vh;
    background: linear-gradient(#e66465, #9198e5);
    background-attachment: fixed;
    background-size: cover;
}
.form-container {
    margin: 20px auto;
    max-width: 500px;
    background-image:linear-gradient(lightgrey,lightpink);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.form-container h1 {
    text-align: center;
    font-weight: bold;
    color: #333;
}

.form-container hr {
    border-top: 1px solid #333;
}

.form-container label {
    display: block;
    margin-bottom: 10px;
}

.form-container input[type="text"],
.form-container input[type="date"],
.form-container select {
    width: 50%;
    padding: 5px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    height:30px
    }

.form-container button {
    width: 200px;
    padding: 10px;
    background-color: #4caf50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    height:40px;
}

.form-container button:hover {
    background-color: #45a049;
}
</style>
</head>
<body class="container display-4">
    <h1 class="text-center font-weight-bold text-white">Doctor's Information</h1><br/>
    <?php 
// Check if 's_id' is set in the URL
if(isset($_GET['s_id'])){
    include("../connection.php"); // Include database connection file
    $s_id = mysqli_real_escape_string($db, $_GET['s_id']); // Sanitize input
    
    // Prepare and execute the query
    $show_doctor_profile_query = "SELECT * FROM doctor INNER JOIN schedule ON schedule.d_id=doctor.id WHERE s_id=?";
    $stmt = mysqli_prepare($db, $show_doctor_profile_query);
    mysqli_stmt_bind_param($stmt, "i", $s_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    // Check if query execution was successful
    if($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
?>
<!-- Grid -->
<div class="w3-row">
    <!-- Blog entries -->
    <div class="w3-col 18 s12">
        <!-- Blog entry -->
        <div class="w3-card-4 w3-margin w3-black">
            <div class="w3-container">
                <h1 class="text-center font-weight-bold text-warning">Personal Information</h1>
                <hr color="#333333" />
                <!-- Display doctor's personal information -->
                <h3 class="text-black">ID : <?php echo $row['id']; ?></h3> 
                <h3 class="text-black">Name : <?php echo $row['f_name'] . ' ' . $row['l_name']; ?></h3>
                <h3 class="text-black">Email/Gmail Address : <?php echo $row['email']; ?></h3>
                <h3 class="text-black">Contact Number : <?php echo $row['contact']; ?></h3>
                <h3 class="text-black">Clinic Address : <?php echo $row['address']; ?></h3>
                <h3 class="text-black">Qualification : <?php echo $row['qualification']; ?></h3>
                <h3 class="text-black">BMDC Registration Number: <?php echo $row['bmdc_reg_num']; ?></h3>
                <h3 class="text-black">Specialism : <?php echo $row['specialist']; ?></h3>
                <h1 class="text-center font-weight-bold text-warning">Visiting/Appointment Information</h1>
                <hr color="#333333" />
                <!-- Display doctor's visiting/appointment information -->
                <p class="text-black font-weight-bold">Schedule ID : <?php echo $row['s_id']; ?></p>
                <ul>
                    <li><?php echo $row['Day_Time1']; ?></li>
                    <li><?php echo $row['Day_Time2']; ?></li>
                    <li><?php echo $row['Day_Time3']; ?></li>
                    <li><?php echo $row['Day_Time4']; ?></li>
                    <li><?php echo $row['Day_Time5']; ?></li>
                    <li><?php echo $row['Day_Time6']; ?></li>
                    <li><?php echo $row['Day_Time7']; ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php 
    } else {
        echo "<p>No doctor found with provided ID.</p>";
    }
} else {
    echo "<p>Your appointment booked successful!!</p>";
}
?>

    <div class="w3-row">
    <div class="w3-col 18 s12">
        <div class="w3-card-4 w3-margin w3-black form-container">
            <div class="w3-container">
                <h1 class="text-center font-weight-bold text-warning">Booking Appointment</h1>
                <hr />
                <form class="text-center text-info font-weight-bold" action="appointment_detail.php" method="POST">
                    <label for="pid" style="font-size: 18px;">Enter Your ID: </label>
                    <input type="text" name="pid" required style="font-size: 18px;" />
                    <label for="sid" style="font-size: 18px;">Enter This ID:</label>
                    <input type="text" name="sid" required style="font-size: 18px;"/>
                    <label for="booking_date" style="font-size: 18px;">Select Date:</label>
                    <input type="date" name="booking_date" required  style="font-size: 18px;"/>
                    <label for="booking_time" style="font-size: 18px;">Select Time:</label>
                    <select name="booking_time" required style="font-size: 18px;">
                        <option value="9:00 AM To 9:30 AM">9:00 AM To 9:30 AM</option> 
                        <option value="9:30 AM To 10:00 AM">9:30 AM To 10:00 AM</option>
                        <option value="10:00 AM To 10:30 AM">10:00 AM To 10:30 AM</option>
                        <option value="10:30 AM To 11:00 AM">10:30 AM To 11:00 AM</option>
                        <option value="11:00 AM To 11:30 AM">11:00 AM To 11:30 AM</option>
                        <option value="1:30 PM To 2:00 PM">1:30 PM To 2:00 PM</option>
                        <option value="2:00 PM To 2:30 PM">2:00 PM To 2:30 PM</option>
                        <option value="2:30 PM To 3:00 PM">2:30 PM To 3:00 PM</option>
                        <option value="3:00 PM To 3:30 PM">3:00 PM To 3:30 PM</option>
                        <option value="3:30 PM To 4:00 PM">3:30 PM To 4:00 PM</option>
                        <option value="6:00 PM To 6:30 PM">6:00 PM To 6:30 PM</option>
                        <option value="6:30 PM To 7:00 PM">6:30 PM To 7:00 PM</option>
                        <option value="7:00 PM To 7:30 PM">7:00 PM To 7:30 PM</option>
                        <option value="7:30 PM To 8:00 PM">7:30 PM To 8:00 PM</option>
                        <option value="8:00 PM To 8:30 PM">8:00 PM To 8:30 PM</option>
                        <option value="8:30 PM To 9:00 PM">8:30 PM To 9:00 PM</option>
                        <!-- Add other time options here -->
                    </select><br /><br />
                    <button type="submit" style="font-size:20px">Submit</button><br />
                    <?php if(isset($error_msg)) { echo $error_msg; } ?>
                    <?php if(isset($update_msg)) { echo $update_msg; } ?>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
