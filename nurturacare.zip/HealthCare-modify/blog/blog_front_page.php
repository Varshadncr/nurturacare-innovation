<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> homehealthcare center homepage</title>
    <link rel="stylesheet" href="home.css">
    <!-- Add these lines to your HTML file -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<body>
 <div class="bgh-container">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark m-auto fixed-top">
        <a class="navbar-brand navbar-logo" href="#"> <img src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706268189/nurturacare-innovations-high-resolution-logo-white-transparent_chdw7k.png" class="image " /></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ml-auto ">
                <a class="nav-item nav-link active" href="#sectionhome">Home <span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link active" href="#sectionaboutus">About us</a>
                <a class="nav-item nav-link active" href="#sectionservices">Services</a>
                <a class="nav-item nav-link active" href="#sectioncontactus">contact us</a>
            </div>
        </div>
    </nav>
    <div class="text-center p-2  " id="sectionhome"><br><br><br>
    <h1 >Welcome to NurturaCare Innovations</h1>
    <p>"Where Compassion Meets Innovation in Home Healthcare. Your Health, Our Priority. Discover a New Era of Personalized and Progressive Care Solutions."</p>
   </div>
      <div class="text-center">
       <img src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706263381/free-medical-background-51_pgazam.png" class="imagecont"/>
       </div>
    <div class="abtus text-center">
       
       
        <div class="d-flex flex-column  shadow text-center p-3 ">
       
           <h2 class="text-center">Our Vision:</h2> 
             <p class="text-center">
To create a nurturing environment where health and well-being thrive, empowering individuals to lead fulfilling lives in the comfort of their homes. </p>
</div>
 <div class="d-flex  flex-column  shadow text-center p-3 ">

<h2 class="text-center ">Our Mission:</h2>
<p class="text-center">
NurturaCare Innovations is committed to providing personalized and progressive home healthcare services. We strive to elevate the quality of care through a unique blend of compassionate attention, state-of-the-art technology, and a commitment to continuous improvement.
        </p>
    </div>
     </div>
            <div class="wcu-section shadow pt-5 pb-5" id="sectionaboutus" >
     
                    <h1 class="wcu-section-heading">Why Choose Us?</h1>
                    <p class="wcu-section-description">
                        Choose us for exceptional healthcare, blending compassion with innovation for your well-being.
                    </p>
               
               <div class="d-flex justify-content-center">
                    <div class="wcu-card p-3 mr-3 shadow">
                        <img src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706276678/compassionate-care-foundation-logo-01-PNG_gyeazb.png" class="wcu-card-image" />
                        <h1 class="wcu-card-title mt-3">Compassionate Care</h1>
                        <p class="wcu-card-description">
                            Our team is driven by a deep commitment to providing care with empathy, respect, and genuine concern for our clients' well-being.
                        </p>
                    </div>
               
                    <div class="wcu-card p-3 mr-3 shadow">
                        <img src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706276807/Innovative_logo_lgzs9g.png" class="wcu-card-image" />
                        <h1 class="wcu-card-title mt-3">Innovative Solutions</h1>
                        <p class="wcu-card-description">
                           We embrace the latest advancements in healthcare technology to deliver efficient and effective solutions tailored to individual needs.
                        </p>
                    </div>
               
               
                    <div class="wcu-card p-3  shadow">
                        <img src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706276972/Caduceus_bgsdge.svg" class="wcu-card-image" />
                        <h1 class="wcu-card-title mt-3">Dedicated Professionals</h1>
                        <p class="wcu-card-description">
                             Our skilled and compassionate professionals are here to support and guide you on your healthcare journey.
                        </p>
                    </div>
                     </div>
                     </div>
                     <div class="bgs" id="sectionservices">
     
           <h1 class="wcu-section-heading p-3">Services We Provide</h1>
                    <p class="wcu-section-description ">
                        Experience personalized and comprehensive healthcare solutions tailored to your needs.
                    </p>
         <div class="slideshow d-flex flex-column justify-content-center">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100 image1" src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706285427/WhatsApp_Image_2024-01-26_at_21.38.52_dcf5b3ae_gwcwkg.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100 image1" src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706285745/WhatsApp_Image_2024-01-26_at_21.44.47_28a8a0dd_h8jczc.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100 image1" src="https://res.cloudinary.com/da41qeo0g/image/upload/v1706284733/WhatsApp_Image_2024-01-26_at_21.20.43_2046c1fa_x3kr9d.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
           </div>
     </div>
            <div class="contactus " id="sectioncontactus">
                  <div class="shadow d-flex flex-column justify-content-center">
                    
                         <h1 class="h1 text-center">Contact Us</h1>
                <div class=" d-flex flex-row justify-content-center social-links text-center">
                    <ul class="list-inline mt-5">
                        <li class="list-inline-item"><a href="https://www.instagram.com/" target="-blank"><i class="fa fa-instagram social-icon" aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="https://twitter.com/VarshaKulk69358" target="-blank"><i class="fa fa-twitter social-icon" aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="https://www.linkedin.com/in/varshakulkarnibgk" target="-blank"><i class="fa fa-linkedin social-icon" aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="mailto:varshakulkarni.bgk@gmail.com" target="-blank"><i class="fa fa-envelope social-icon" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
            </div>
   
            <div class="d-flex  flex-row text-grey justify-content-center">
                <footer>
                    <p>
                        &copy; 2024 NCI. All rights reserved.</p>
                    <p class="text-center">Owners:</p><p>varsha raghavendra kulkarni<br/>c adarsha </p>
                    
                </footer>
            </div>
                
                
                
            </div>
        
 

  
</body>
</html>
